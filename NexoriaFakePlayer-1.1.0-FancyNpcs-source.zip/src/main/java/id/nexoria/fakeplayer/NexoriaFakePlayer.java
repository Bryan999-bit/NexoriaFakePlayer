package id.nexoria.fakeplayer;

import de.oliver.fancynpcs.api.FancyNpcsPlugin;
import id.nexoria.fakeplayer.command.FakeCommand;
import id.nexoria.fakeplayer.listener.FakeListener;
import id.nexoria.fakeplayer.manager.FakeManager;
import id.nexoria.fakeplayer.manager.GuiManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class NexoriaFakePlayer extends JavaPlugin {
    private FakeManager fakeManager; private GuiManager guiManager;
    @Override public void onEnable(){saveDefaultConfig();saveResource("messages.yml",false);
        if(Bukkit.getPluginManager().getPlugin("FancyNpcs")==null||FancyNpcsPlugin.get()==null){getLogger().severe("FancyNpcs 2.12.1 tidak ditemukan. Plugin dinonaktifkan.");Bukkit.getPluginManager().disablePlugin(this);return;}
        fakeManager=new FakeManager(this);guiManager=new GuiManager(this,fakeManager);FakeCommand command=new FakeCommand(this,fakeManager,guiManager);getCommand("fake").setExecutor(command);getCommand("fake").setTabCompleter(command);
        Bukkit.getPluginManager().registerEvents(new FakeListener(this,fakeManager,guiManager),this);fakeManager.start();getLogger().info("NexoriaFakePlayer aktif dengan FancyNpcs API.");
        getLogger().warning("NPC FancyNpcs adalah entitas visual berbasis paket; combat dan damage fisik tidak tersedia seperti pemain asli.");
    }
    @Override public void onDisable(){if(fakeManager!=null)fakeManager.shutdown();}
}
