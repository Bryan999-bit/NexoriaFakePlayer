package id.nexoria.fakeplayer.command;

import de.oliver.fancynpcs.api.Npc;
import id.nexoria.fakeplayer.NexoriaFakePlayer;
import id.nexoria.fakeplayer.manager.FakeManager;
import id.nexoria.fakeplayer.manager.GuiManager;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.Locale;

public final class FakeCommand implements CommandExecutor, TabCompleter {
    private final NexoriaFakePlayer plugin; private final FakeManager manager; private final GuiManager gui;
    public FakeCommand(NexoriaFakePlayer plugin, FakeManager manager, GuiManager gui) { this.plugin=plugin; this.manager=manager; this.gui=gui; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("nexoria.fakeplayer.admin")) { sender.sendMessage("§cKamu tidak memiliki izin."); return true; }
        if (args.length == 0) { if (sender instanceof Player p) gui.open(p); else sender.sendMessage("Gunakan /fake create <nama>, remove <nama>, list, reload."); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> { if (!(sender instanceof Player p)) { sender.sendMessage("Hanya pemain."); return true; }
                if (args.length < 2) { sender.sendMessage("§c/fake create <nama>"); return true; }
                Npc npc=manager.create(args[1], p.getLocation()); sender.sendMessage(npc==null?"§cNama sudah dipakai atau batas NPC tercapai.":"§aDibuat: §f"+npc.getData().getName()); }
            case "remove" -> { if (args.length<2 || !manager.remove(args[1])) sender.sendMessage("§cNPC tidak ditemukan."); else sender.sendMessage("§aNPC dihapus."); }
            case "list" -> { List<String> names=manager.getNpcs().stream().map(n->n.getData().getName()).toList(); sender.sendMessage("§bFake Player: §f"+(names.isEmpty()?"kosong":String.join(", ",names))); }
            case "pause", "resume" -> { if(args.length<2){sender.sendMessage("§c/fake "+args[0]+" <nama>");return true;} Npc npc=manager.find(args[1]); if(npc==null)sender.sendMessage("§cNPC tidak ditemukan."); else {manager.setPaused(npc,args[0].equalsIgnoreCase("pause"));sender.sendMessage("§aStatus aktivitas diperbarui.");} }
            case "tp" -> { if (!(sender instanceof Player p)||args.length<2)return true; Npc npc=manager.find(args[1]); if(npc==null)sender.sendMessage("§cNPC tidak ditemukan."); else p.teleport(npc.getData().getLocation()); }
            case "reload" -> { plugin.reloadConfig(); sender.sendMessage("§aConfig dimuat ulang."); }
            default -> sender.sendMessage("§c/fake [create|remove|list|tp|pause|resume|reload]");
        } return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if(args.length==1)return List.of("create","remove","list","tp","pause","resume","reload");
        if(args.length==2 && List.of("remove","tp","pause","resume").contains(args[0].toLowerCase(Locale.ROOT)))return manager.getNpcs().stream().map(n->n.getData().getName()).toList();
        return List.of();
    }
}
