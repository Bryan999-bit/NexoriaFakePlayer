package id.nexoria.fakeplayer.manager;

import de.oliver.fancynpcs.api.Npc;
import id.nexoria.fakeplayer.NexoriaFakePlayer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.List;

public final class GuiManager {
    public static final String TITLE = "§8Nexoria §bFakePlayer";
    private final NexoriaFakePlayer plugin; private final FakeManager manager;
    public GuiManager(NexoriaFakePlayer plugin, FakeManager manager){this.plugin=plugin;this.manager=manager;}
    public void open(Player player){Inventory inv=Bukkit.createInventory(null,27,TITLE);
        inv.setItem(10,item(Material.PLAYER_HEAD,"§aBuat Fake Player","§7Buat NPC di lokasimu."));
        inv.setItem(12,item(Material.WRITABLE_BOOK,"§bDaftar Fake Player","§7Lihat daftar NPC."));
        inv.setItem(14,item(Material.REDSTONE_TORCH,"§eMode TAB","§7TAB visible: "+plugin.getConfig().getBoolean("tab-visible",true)));
        inv.setItem(16,item(Material.COMPARATOR,"§6Reload Config","§7Muat ulang konfigurasi.")); player.openInventory(inv);}
    private ItemStack item(Material m,String name,String lore){ItemStack s=new ItemStack(m);ItemMeta meta=s.getItemMeta();meta.setDisplayName(name);meta.setLore(List.of(lore));s.setItemMeta(meta);return s;}
    public void click(Player player,int slot){switch(slot){
        case 10->{String name="Nexo"+(100+(int)(Math.random()*900));Npc npc=manager.create(name,player.getLocation());player.sendMessage(npc==null?"§cGagal membuat NPC.":"§aFake Player dibuat: §f"+npc.getData().getName());player.closeInventory();}
        case 12->{List<String> names=manager.getNpcs().stream().map(n->n.getData().getName()).toList();player.sendMessage("§bFake Player: §f"+(names.isEmpty()?"Belum ada":String.join(", ",names)));player.closeInventory();}
        case 14->{boolean next=!plugin.getConfig().getBoolean("tab-visible",true);plugin.getConfig().set("tab-visible",next);plugin.saveConfig();manager.setTabVisible(next);player.sendMessage("§aTAB visible: "+next);open(player);}
        case 16->{plugin.reloadConfig();player.sendMessage("§aKonfigurasi dimuat ulang.");player.closeInventory();} default->{}}
    }
}
