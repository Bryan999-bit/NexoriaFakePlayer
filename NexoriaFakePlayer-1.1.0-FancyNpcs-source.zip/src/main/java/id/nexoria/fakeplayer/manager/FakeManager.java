package id.nexoria.fakeplayer.manager;

import de.oliver.fancynpcs.api.FancyNpcsPlugin;
import de.oliver.fancynpcs.api.Npc;
import de.oliver.fancynpcs.api.NpcData;
import id.nexoria.fakeplayer.NexoriaFakePlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** FancyNpcs-backed visual NPC manager. FancyNpcs NPCs are packet entities, not real players. */
public final class FakeManager {
    private static final String ID_PREFIX = "nexoria_fp_";
    private final NexoriaFakePlayer plugin;
    private final Set<String> paused = new HashSet<>();
    private final Map<String, Location> destinations = new HashMap<>();
    private BukkitTask task;

    public FakeManager(NexoriaFakePlayer plugin) { this.plugin = plugin; }

    private de.oliver.fancynpcs.api.NpcManager registry() {
        return FancyNpcsPlugin.get().getNpcManager();
    }

    public List<Npc> getNpcs() {
        if (FancyNpcsPlugin.get() == null || registry() == null) return List.of();
        return registry().getAllNpcs().stream().filter(this::isManaged).toList();
    }

    public Npc find(String name) {
        return getNpcs().stream().filter(n -> n.getData().getName().equalsIgnoreCase(name)
                || n.getData().getId().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public boolean isManaged(Npc npc) {
        return npc.getData().getId().toLowerCase(Locale.ROOT).startsWith(ID_PREFIX);
    }

    public Npc create(String name, Location location) {
        int max = plugin.getConfig().getInt("max-npcs", -1);
        if (max >= 0 && getNpcs().size() >= max) return null;
        if (find(name) != null) return null;
        String id = ID_PREFIX + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
        NpcData data = new NpcData(id, UUID.randomUUID(), location.clone());
        data.setDisplayName(name);
        data.setShowInTab(plugin.getConfig().getBoolean("tab-visible", true));
        data.setSpawnEntity(true);
        data.setTurnToPlayer(true);
        Npc npc = FancyNpcsPlugin.get().getNpcAdapter().apply(data);
        npc.create();
        registry().registerNpc(npc);
        npc.spawnForAll();
        registry().saveNpcs(false);
        return npc;
    }

    public boolean remove(String name) {
        Npc npc = find(name);
        if (npc == null) return false;
        String id = npc.getData().getId();
        paused.remove(id);
        destinations.remove(id);
        npc.removeForAll();
        registry().removeNpc(npc);
        registry().saveNpcs(false);
        return true;
    }

    public void setPaused(Npc npc, boolean value) {
        if (value) paused.add(npc.getData().getId()); else paused.remove(npc.getData().getId());
    }

    public boolean isPaused(Npc npc) { return paused.contains(npc.getData().getId()); }

    public void setTabVisible(boolean visible) {
        for (Npc npc : getNpcs()) {
            npc.getData().setShowInTab(visible);
            npc.updateForAll(true);
        }
        registry().saveNpcs(false);
    }

    public void start() {
        long interval = Math.max(5, plugin.getConfig().getLong("behavior.adventure-interval-seconds", 18));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, interval * 20L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Npc npc : getNpcs()) npc.spawnForAll();
        }, 40L);
    }

    private void tick() {
        if (FancyNpcsPlugin.get() == null) return;
        String mode = plugin.getConfig().getString("behavior.mode", "mixed").toLowerCase(Locale.ROOT);
        for (Npc npc : getNpcs()) {
            if (isPaused(npc)) continue;
            wander(npc);
            if (plugin.getConfig().getBoolean("chat.random-chat-enabled", true)
                    && ThreadLocalRandom.current().nextInt(4) == 0) sayRandom(npc);
            // Mob hunting is represented as NPC activity/chat only: FancyNpcs NPCs are packet entities.
            if (!mode.equals("peaceful") && plugin.getConfig().getBoolean("behavior.attack-mobs", true))
                observeNearbyMobs(npc);
        }
    }

    private void wander(Npc npc) {
        String id = npc.getData().getId();
        Location current = npc.getData().getLocation();
        if (current == null || current.getWorld() == null) return;
        Location destination = destinations.get(id);
        if (destination == null || current.distanceSquared(destination) < 2.25) {
            int radius = Math.max(4, plugin.getConfig().getInt("behavior.adventure-radius", 48));
            ThreadLocalRandom r = ThreadLocalRandom.current();
            Location candidate = current.clone().add(r.nextInt(-radius, radius + 1), 0, r.nextInt(-radius, radius + 1));
            candidate.setY(candidate.getWorld().getHighestBlockYAt(candidate) + 1);
            if (!candidate.getBlock().isPassable() || !candidate.clone().add(0, 1, 0).getBlock().isPassable()) return;
            destination = candidate;
            destinations.put(id, destination);
        }
        double dx = destination.getX() - current.getX();
        double dz = destination.getZ() - current.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 0.1) return;
        double step = Math.min(1.2, length);
        Location next = current.clone().add(dx / length * step, 0, dz / length * step);
        next.setY(current.getWorld().getHighestBlockYAt(next) + 1);
        next.setDirection(destination.toVector().subtract(next.toVector()));
        npc.getData().setLocation(next);
        npc.moveForAll(true);
        npc.updateForAll(true);
    }

    private void observeNearbyMobs(Npc npc) {
        Location loc = npc.getData().getLocation();
        if (loc == null || loc.getWorld() == null) return;
        int range = plugin.getConfig().getInt("behavior.max-target-distance", 20);
        boolean nearby = loc.getWorld().getNearbyEntities(loc, range, range, range).stream()
                .anyMatch(e -> e instanceof org.bukkit.entity.LivingEntity && !(e instanceof Player)
                        && e.getType() != EntityType.ARMOR_STAND);
        if (nearby && ThreadLocalRandom.current().nextInt(5) == 0)
            Bukkit.broadcastMessage("§8[§bNexoria§8] §f" + npc.getData().getName() + " §7sedang mengamati mob di sekitar.");
    }

    private void sayRandom(Npc npc) {
        List<String> messages = plugin.getConfig().getStringList("chat.messages");
        if (messages.isEmpty()) return;
        String message = messages.get(ThreadLocalRandom.current().nextInt(messages.size()));
        Bukkit.broadcastMessage("§8[§b" + npc.getData().getName() + "§8] §f" + message);
    }

    public void onPlayerInteract(Player player, Npc npc) {
        if (!isManaged(npc) || isPaused(npc)) return;
        player.sendMessage("§8[§b" + npc.getData().getName() + "§8] §fHalo " + player.getName() + "!");
    }

    public void shutdown() {
        if (task != null) task.cancel();
        if (FancyNpcsPlugin.get() != null && registry() != null) registry().saveNpcs(false);
    }
}
