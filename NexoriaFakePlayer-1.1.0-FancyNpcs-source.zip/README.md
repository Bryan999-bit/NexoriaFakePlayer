# NexoriaFakePlayer 1.1.0 (FancyNpcs edition)

Build target: Java 25, Gradle 9.1.0, Paper 26.2 API baseline.

## Dependency
- FancyNpcs 2.12.1 must be installed on the server.
- The FancyNpcs 2.12.1 API jar is bundled in `libs/` for GitHub Actions compilation. It is `compileOnly` and is NOT shaded into the plugin JAR.
- Citizens and PacketEvents are not required by this edition.

## Build
Run `clean build`. Output: `build/libs/NexoriaFakePlayer-1.1.0.jar`.

## Commands
- `/fake` opens the admin GUI
- `/fake create <name>`
- `/fake remove <name>`
- `/fake list`
- `/fake pause <name>` / `/fake resume <name>`
- `/fake tp <name>`
- `/fake reload`

Permission: `nexoria.fakeplayer.admin` (default OP).

## Important limitations
FancyNpcs NPCs are packet-based visual NPCs, not real Bukkit Player entities. This edition supports shared visibility, TAB visibility, visual wandering, greeting/chat behavior, click responses, GUI management, and persistence through FancyNpcs. Mob hunting is only represented as observation/chat behavior. Real physical combat, taking damage, and retaliation against attackers are not implemented because packet NPCs do not receive normal entity damage events like real players.

The unlimited setting (`max-npcs: -1`) removes the plugin's own cap, but server performance and FancyNpcs still limit practical counts. Test on a staging server before production.
