package id.nexoria.fakeplayer.listener;

import id.nexoria.fakeplayer.NexoriaFakePlayer;
import id.nexoria.fakeplayer.manager.FakeManager;
import id.nexoria.fakeplayer.manager.GuiManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.concurrent.ThreadLocalRandom;

public final class FakeListener implements Listener {
    private final NexoriaFakePlayer plugin;
    private final FakeManager manager;
    private final GuiManager gui;

    public FakeListener(NexoriaFakePlayer plugin, FakeManager manager, GuiManager gui) {
        this.plugin = plugin; this.manager = manager; this.gui = gui;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) { manager.onDamage(event); }

    @EventHandler
    public void onDeath(EntityDeathEvent event) { manager.onDeath(event); }

    @EventHandler
    public void onGui(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals("§8Nexoria §bFakePlayer")) return;
        event.setCancelled(true);
        if (event.getWhoClicked() instanceof Player player) gui.click(player, event.getRawSlot());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.getConfig().getBoolean("chat.join-greeting-enabled", true)) return;
        long delay = plugin.getConfig().getLong("chat.join-greeting-delay-ticks", 60);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!event.getPlayer().isOnline()) return;
            String[] lines = {
                    "§b[Explorer] §fSelamat datang, " + event.getPlayer().getName() + "! Semoga betah.",
                    "§b[Traveler] §fHai " + event.getPlayer().getName() + ", selamat bertualang!",
                    "§b[Adventurer] §fWelcome ke Nexoria, " + event.getPlayer().getName() + "!"
            };
            if (plugin.getConfig().getBoolean("chat.enabled", true)) {
                Bukkit.broadcastMessage(lines[ThreadLocalRandom.current().nextInt(lines.length)]);
            }
        }, Math.max(1, delay));
    }

    @EventHandler
    @SuppressWarnings("deprecation")
    public void onChat(AsyncPlayerChatEvent event) {
        if (!plugin.getConfig().getBoolean("chat.enabled", true)) return;
        String message = event.getMessage().toLowerCase();
        if (!(message.contains("hai") || message.contains("halo") || message.contains("hello")
                || message.contains("ada yang") || message.contains("siapa"))) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            String[] replies = {
                    "§b[Explorer] §fHalo! Aku sedang menjelajahi dunia.",
                    "§b[Traveler] §fAda yang bisa kubantu?",
                    "§b[Adventurer] §fAku baru saja melihat beberapa mob di sekitar sini."
            };
            Bukkit.broadcastMessage(replies[ThreadLocalRandom.current().nextInt(replies.length)]);
        });
    }
}
