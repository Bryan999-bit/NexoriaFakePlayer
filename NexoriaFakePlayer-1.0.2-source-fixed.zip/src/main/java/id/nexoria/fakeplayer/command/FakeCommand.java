package id.nexoria.fakeplayer.command;

import id.nexoria.fakeplayer.NexoriaFakePlayer;
import id.nexoria.fakeplayer.manager.FakeManager;
import id.nexoria.fakeplayer.manager.GuiManager;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class FakeCommand implements CommandExecutor, TabCompleter {
    private final NexoriaFakePlayer plugin;
    private final FakeManager manager;
    private final GuiManager gui;

    public FakeCommand(NexoriaFakePlayer plugin, FakeManager manager, GuiManager gui) {
        this.plugin = plugin; this.manager = manager; this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("nexoria.fakeplayer.admin")) {
            sender.sendMessage("§cKamu tidak memiliki izin."); return true;
        }
        if (args.length == 0) {
            if (sender instanceof Player player) gui.open(player);
            else sender.sendMessage("Gunakan /fake create <nama>, remove <nama>, list, reload.");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Hanya pemain."); return true; }
                if (args.length < 2) { sender.sendMessage("§c/fake create <nama>"); return true; }
                NPC npc = manager.create(args[1], player.getLocation());
                sender.sendMessage(npc == null ? "§cBatas NPC tercapai." : "§aDibuat: " + npc.getName());
            }
            case "remove" -> {
                if (args.length < 2 || !manager.remove(args[1])) sender.sendMessage("§cNPC tidak ditemukan.");
                else sender.sendMessage("§aNPC dihapus.");
            }
            case "list" -> {
                List<String> names = manager.getNpcs().stream().filter(manager::isManaged)
                        .map(NPC::getName).collect(Collectors.toList());
                sender.sendMessage("§bFake Player: §f" + (names.isEmpty() ? "kosong" : String.join(", ", names)));
            }
            case "pause", "resume" -> {
                if (args.length < 2) { sender.sendMessage("§c/fake " + args[0] + " <nama>"); return true; }
                NPC npc = manager.find(args[1]);
                if (npc == null) { sender.sendMessage("§cNPC tidak ditemukan."); return true; }
                manager.setPaused(npc, args[0].equalsIgnoreCase("pause"));
                sender.sendMessage("§aStatus aktivitas diperbarui.");
            }
            case "tp" -> {
                if (!(sender instanceof Player player) || args.length < 2) return true;
                NPC npc = manager.find(args[1]);
                if (npc == null || !npc.isSpawned()) sender.sendMessage("§cNPC tidak ditemukan/aktif.");
                else player.teleport(npc.getEntity().getLocation());
            }
            case "reload" -> {
                plugin.reloadConfig(); sender.sendMessage("§aConfig dimuat ulang.");
            }
            default -> sender.sendMessage("§c/fake [create|remove|list|tp|pause|resume|reload]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("create", "remove", "list", "tp", "pause", "resume", "reload");
        if (args.length == 2 && List.of("remove", "tp", "pause", "resume").contains(args[0].toLowerCase(Locale.ROOT))) {
            return manager.getNpcs().stream().filter(manager::isManaged).map(NPC::getName).toList();
        }
        return List.of();
    }
}
