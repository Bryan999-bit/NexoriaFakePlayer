package id.nexoria.fakeplayer.manager;

import id.nexoria.fakeplayer.NexoriaFakePlayer;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class GuiManager {
    private final NexoriaFakePlayer plugin;
    private final FakeManager manager;
    private final String title = "§8Nexoria §bFakePlayer";

    public GuiManager(NexoriaFakePlayer plugin, FakeManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, title);
        inv.setItem(10, item(Material.PLAYER_HEAD, "§aBuat Fake Player", "§7Buat NPC di lokasimu."));
        inv.setItem(12, item(Material.WRITABLE_BOOK, "§bDaftar Fake Player", "§7Klik untuk melihat NPC di chat."));
        inv.setItem(14, item(Material.REDSTONE_TORCH, "§eMode TAB", "§7TAB visible: " + plugin.getConfig().getBoolean("tab-visible")));
        inv.setItem(16, item(Material.COMPARATOR, "§6Reload Config", "§7Muat ulang konfigurasi."));
        player.openInventory(inv);
    }

    private ItemStack item(Material material, String name, String lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(List.of(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    public void click(Player player, int slot) {
        switch (slot) {
            case 10 -> {
                String name = "Nexo" + (100 + (int)(Math.random() * 900));
                NPC npc = manager.create(name, player.getLocation());
                player.sendMessage(npc == null ? "§cBatas Fake Player tercapai." : "§aFake Player dibuat: §f" + npc.getName());
                player.closeInventory();
            }
            case 12 -> {
                List<String> names = new ArrayList<>();
                for (NPC npc : manager.getNpcs()) if (manager.isManaged(npc)) names.add(npc.getName());
                player.sendMessage("§bFake Player: §f" + (names.isEmpty() ? "Belum ada" : String.join(", ", names)));
                player.closeInventory();
            }
            case 14 -> {
                boolean next = !plugin.getConfig().getBoolean("tab-visible", true);
                plugin.getConfig().set("tab-visible", next);
                plugin.saveConfig();
                for (NPC npc : manager.getNpcs()) {
                    if (manager.isManaged(npc)) {
                        npc.data().setPersistent(NPC.Metadata.REMOVE_FROM_TABLIST, !next);
                    }
                }
                player.sendMessage("§aTAB visible: " + next);
                open(player);
            }
            case 16 -> {
                plugin.reloadConfig();
                player.sendMessage("§aKonfigurasi dimuat ulang.");
                player.closeInventory();
            }
            default -> { }
        }
    }
}
