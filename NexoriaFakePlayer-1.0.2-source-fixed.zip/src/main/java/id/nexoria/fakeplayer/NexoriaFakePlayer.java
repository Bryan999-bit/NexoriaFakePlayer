package id.nexoria.fakeplayer;

import id.nexoria.fakeplayer.command.FakeCommand;
import id.nexoria.fakeplayer.listener.FakeListener;
import id.nexoria.fakeplayer.manager.FakeManager;
import id.nexoria.fakeplayer.manager.GuiManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class NexoriaFakePlayer extends JavaPlugin {
    private FakeManager fakeManager;
    private GuiManager guiManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);

        if (Bukkit.getPluginManager().getPlugin("Citizens") == null) {
            getLogger().severe("Citizens tidak ditemukan. Plugin dinonaktifkan.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        fakeManager = new FakeManager(this);
        guiManager = new GuiManager(this, fakeManager);

        FakeCommand command = new FakeCommand(this, fakeManager, guiManager);
        getCommand("fake").setExecutor(command);
        getCommand("fake").setTabCompleter(command);

        Bukkit.getPluginManager().registerEvents(new FakeListener(this, fakeManager, guiManager), this);
        fakeManager.start();

        boolean packetEvents = Bukkit.getPluginManager().getPlugin("packetevents") != null;
        getLogger().info("NexoriaFakePlayer aktif. PacketEvents tersedia: " + packetEvents);
        getLogger().info("NPC dikelola oleh Citizens; PacketEvents disiapkan sebagai dependensi integrasi packet.");
    }

    @Override
    public void onDisable() {
        if (fakeManager != null) fakeManager.shutdown();
    }

    public FakeManager getFakeManager() { return fakeManager; }
}
