# NexoriaFakePlayer 1.0.0

Starter project for a Paper server using Citizens and PacketEvents.

## Build
Requires Java 25 and Gradle 9.1.0 or newer compatible with Java 25.

```bash
gradle clean build
```

The JAR is created in `build/libs/`.

## Dependencies
- Paper API 1.21.11 compile-time baseline
- Citizens 2.0.39-SNAPSHOT (provided by the server)
- PacketEvents 2.9.5 (provided by the server)

Check compatibility with the exact Paper build used by your host before installing on a live server.

## Important
This is an early starter implementation, not a production-ready full player simulator. PacketEvents integration, advanced combat, and full player-like behavior still require implementation and testing.
