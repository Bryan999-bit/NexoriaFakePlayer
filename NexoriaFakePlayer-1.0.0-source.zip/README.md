# NexoriaFakePlayer 1.0.0

Starter project for a Paper server using Citizens and PacketEvents.

## Target
- Java 25
- Paper 26.2 API (adjust `paper-api` version if your hosting uses a different published API coordinate)
- Citizens 2.0.39-SNAPSHOT
- PacketEvents 2.9.5

## Build
Run with Gradle 8.14+ / compatible Gradle:
```bash
gradle clean build
```
The jar is created at `build/libs/NexoriaFakePlayer-1.0.0.jar`.

## Install
1. Install Citizens on the server.
2. Install PacketEvents on the server.
3. Put `NexoriaFakePlayer-1.0.0.jar` in `plugins/`.
4. Restart the server.
5. Use `/fake`.

## Commands
- `/fake` - open admin GUI
- `/fake create <name>`
- `/fake remove <name>`
- `/fake list`
- `/fake tp <name>`
- `/fake pause <name>`
- `/fake resume <name>`
- `/fake reload`

Permission: `nexoria.fakeplayer.admin` (default OP).

## Important implementation notes
- Citizens owns NPC creation, navigation and persistent NPC storage.
- PacketEvents is declared as a runtime soft dependency for packet-level extensions. This initial source does not yet register custom PacketEvents listeners or implement a real client-side player connection.
- NPC chat replies and join greetings are scripted templates, not a generative AI model.
- Combat currently implements retaliation targeting and damage attribution hooks; full player-like attack animations, pathfinding combat tactics, loot handling and robust NPC-vs-mob combat need additional testing and iteration against the exact server build.
- "Unlimited" removes the plugin's configured count cap; it does not remove hardware, view-distance, entity-tick or client packet limits.
- TAB visibility uses Citizens NPC metadata and should be verified with your TAB plugin and exact Citizens build.
- This is source code for a starter implementation, not a claim that a compiled, production-ready jar has already been tested on your host.
