package id.nexoria.fakeplayer.manager;

import id.nexoria.fakeplayer.NexoriaFakePlayer;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class FakeManager {
    private final NexoriaFakePlayer plugin;
    private final Map<UUID, Long> lastAttack = new HashMap<>();
    private final Map<UUID, Long> lastPlayerHit = new HashMap<>();
    private final Set<UUID> paused = new HashSet<>();
    private BukkitTask task;

    public FakeManager(NexoriaFakePlayer plugin) { this.plugin = plugin; }

    public Collection<NPC> getNpcs() {
        return CitizensAPI.getNPCRegistry().sorted();
    }

    public NPC find(String name) {
        for (NPC npc : getNpcs()) {
            if (npc.getName().equalsIgnoreCase(name) && isManaged(npc)) return npc;
        }
        return null;
    }

    public boolean isManaged(NPC npc) {
        return npc.data().has("nexoria_fakeplayer");
    }

    public NPC create(String name, Location location) {
        int max = plugin.getConfig().getInt("max-npcs", -1);
        long current = getNpcs().stream().filter(this::isManaged).count();
        if (max >= 0 && current >= max) return null;

        NPC npc = CitizensAPI.getNPCRegistry().createNPC(EntityType.PLAYER, name);
        npc.data().setPersistent("nexoria_fakeplayer", true);
        npc.data().setPersistent("nexoria_paused", false);
        npc.data().setPersistent(NPC.Metadata.REMOVE_FROM_TABLIST,
                !plugin.getConfig().getBoolean("tab-visible", true));
        npc.spawn(location);
        return npc;
    }

    public boolean remove(String name) {
        NPC npc = find(name);
        if (npc == null) return false;
        paused.remove(npc.getUniqueId());
        lastAttack.remove(npc.getUniqueId());
        lastPlayerHit.remove(npc.getUniqueId());
        npc.destroy();
        return true;
    }

    public void setPaused(NPC npc, boolean value) {
        if (value) paused.add(npc.getUniqueId());
        else paused.remove(npc.getUniqueId());
        npc.data().setPersistent("nexoria_paused", value);
    }

    public boolean isPaused(NPC npc) { return paused.contains(npc.getUniqueId()); }

    public void start() {
        // Restore pause state from Citizens persistent NPC data.
        for (NPC npc : getNpcs()) {
            if (isManaged(npc) && npc.data().get("nexoria_paused", false)) paused.add(npc.getUniqueId());
        }
        long interval = Math.max(5, plugin.getConfig().getLong("behavior.adventure-interval-seconds", 18));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, interval * 20L);
    }

    private void tick() {
        String mode = plugin.getConfig().getString("behavior.mode", "mixed").toLowerCase(Locale.ROOT);
        for (NPC npc : getNpcs()) {
            if (!isManaged(npc) || !npc.isSpawned() || isPaused(npc)) continue;
            if (mode.equals("peaceful") || mode.equals("mixed") || mode.equals("aggressive")) {
                wander(npc);
            }
            if (!mode.equals("peaceful") && plugin.getConfig().getBoolean("behavior.attack-mobs", true)) {
                huntNearbyMob(npc);
            }
        }
    }

    private void wander(NPC npc) {
        Location base = npc.getStoredLocation();
        if (npc.getEntity() != null) base = npc.getEntity().getLocation();
        if (base == null || base.getWorld() == null || !npc.getNavigator().isNavigating()) {
            if (base == null || base.getWorld() == null) return;
            int radius = Math.max(8, plugin.getConfig().getInt("behavior.adventure-radius", 48));
            ThreadLocalRandom random = ThreadLocalRandom.current();
            int dx = random.nextInt(-radius, radius + 1);
            int dz = random.nextInt(-radius, radius + 1);
            Location target = base.clone().add(dx, 0, dz);
            target.setY(base.getWorld().getHighestBlockYAt(target) + 1);
            if (target.getBlock().isPassable() && target.clone().add(0, 1, 0).getBlock().isPassable()) {
                npc.getNavigator().setTarget(target);
            }
        }
    }

    private void huntNearbyMob(NPC npc) {
        if (!(npc.getEntity() instanceof LivingEntity hunter)) return;
        int range = plugin.getConfig().getInt("behavior.max-target-distance", 20);
        LivingEntity target = hunter.getNearbyEntities(range, range, range).stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> !(e instanceof Player))
                .filter(e -> e.getType() != EntityType.ARMOR_STAND)
                .min(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(hunter.getLocation())))
                .orElse(null);
        if (target != null && !npc.getNavigator().isNavigating()) npc.getNavigator().setTarget(target);
    }

    public void onDamage(EntityDamageByEntityEvent event) {
        NPC victimNpc = CitizensAPI.getNPCRegistry().getNPC(event.getEntity());
        if (victimNpc != null && isManaged(victimNpc) && event.getDamager() instanceof Player attacker) {
            lastPlayerHit.put(victimNpc.getUniqueId(), System.currentTimeMillis());
            if (plugin.getConfig().getBoolean("behavior.retaliate-against-players", true)
                    && !attacker.getGameMode().name().equals("CREATIVE")
                    && !attacker.getGameMode().name().equals("SPECTATOR")) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (victimNpc.isSpawned() && attacker.isOnline()) victimNpc.getNavigator().setTarget(attacker);
                });
            }
            return;
        }

        NPC attackerNpc = CitizensAPI.getNPCRegistry().getNPC(event.getDamager());
        if (attackerNpc != null && isManaged(attackerNpc)) {
            event.setDamage(plugin.getConfig().getDouble("behavior.attack-damage", 3.0));
        }
    }

    public void onDeath(EntityDeathEvent event) {
        NPC deadNpc = CitizensAPI.getNPCRegistry().getNPC(event.getEntity());
        if (deadNpc != null && isManaged(deadNpc)) {
            setPaused(deadNpc, true);
            Bukkit.broadcastMessage("§8[§bNexoria§8] §7Petualang §f" + deadNpc.getName() + " §7telah gugur.");
        }
    }

    public void shutdown() {
        if (task != null) task.cancel();
    }
}
